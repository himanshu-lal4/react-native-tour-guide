import type { EdgeInsets, MeasurableRef, SpotlightTarget } from './types';
import type { SpotlightBorderRadius } from './shapes';
/**
 * Compute the best tooltip position based on available screen space.
 * Prefers: bottom > top > right > left.
 * `insets` shrink the usable area so the tour avoids system chrome.
 */
interface TooltipPositionOptions {
    target: SpotlightTarget;
    screenWidth: number;
    screenHeight: number;
    tooltipWidth: number;
    tooltipHeight?: number;
    offset?: number;
    insets?: EdgeInsets;
}
export declare const computeTooltipPosition: ({ target, screenWidth, screenHeight, tooltipWidth, tooltipHeight, offset, insets, }: TooltipPositionOptions) => "top" | "bottom" | "left" | "right";
/**
 * Resolve just the safe-area insets (auto-detected, or overridden via
 * `config.insets`) — WITHOUT any `extraInsets`. This is the value that mirrors
 * system chrome like the status bar, and is what corrects `measureInWindow`
 * coordinates on Android (see TourGuideOverlay).
 */
export declare const resolveSafeAreaInsets: (config?: {
    insets?: Partial<EdgeInsets>;
}) => EdgeInsets;
/**
 * Resolve the effective insets the tour should respect for layout/clamping:
 * the safe area plus any `config.extraInsets` for app chrome like tab bars and
 * headers.
 */
export declare const resolveInsets: (config?: {
    insets?: Partial<EdgeInsets>;
    extraInsets?: Partial<EdgeInsets>;
}) => EdgeInsets;
/**
 * Validate that a ref is valid and points to a mounted component.
 * Returns true if valid, false otherwise.
 */
export declare const validateRef: (ref: MeasurableRef | undefined, stepId: string) => boolean;
/**
 * Extract border radius values from a View style.
 * Returns a SpotlightBorderRadius (number if uniform, object if per-corner),
 * or undefined if no border radius is specified.
 *
 * Percentage radii (e.g. `'50%'`, supported by React Native 0.76+) are resolved
 * against the target's shorter side when `target` dimensions are provided — this
 * is what keeps a circular avatar (`borderRadius: '50%'`) round instead of square.
 * Without `target`, percentages fall back to the numeric base/0.
 */
export declare const extractBorderRadius: (style: any, target?: {
    width: number;
    height: number;
}) => SpotlightBorderRadius | undefined;
export {};
//# sourceMappingURL=utils.d.ts.map